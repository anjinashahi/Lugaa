<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Management</title>
    <style>
        /* CSS for layout */
        .container {
            margin: 20px;
        }
        .seller-card {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
            width: 200px; /* Adjust width as needed */
            display: inline-block;
            margin-right: 10px;
        }
        .seller-card img {
            max-width: 100px;
            max-height: 100px;
            display: block;
            margin: 0 auto;
            margin-bottom: 10px;
        }
        .seller-card p {
            margin: 5px 0;
        }
        #addBtn, #deleteBtn {
            float: right;
            margin-left: 10px;
        }
        /* CSS for modal */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            padding-top: 60px;
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <button id="addBtn">Add Seller</button>
        <button id="deleteBtn">Delete Seller</button>
        <div id="sellerCards">
            <!-- PHP code to fetch and display seller information -->
            <?php
            // Include database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "collab_main";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch sellers from database and display as ID cards
            $sql = "SELECT * FROM seller";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<div class='seller-card'>";
                    echo "<img src='data:image/jpeg;base64," . base64_encode($row['photo']) . "' alt='Seller Photo'>";
                    echo "<p><strong>Username:</strong> " . $row['username'] . "</p>";
                    echo "<p><strong>Email:</strong> " . $row['email'] . "</p>";
                    echo "<p><strong>Full Name:</strong> " . $row['full_name'] . "</p>";
                    echo "<p><strong>Phone Number:</strong> " . $row['phone_number'] . "</p>";
                    echo "<p><strong>Address:</strong> " . $row['address'] . "</p>";
                    echo "<p><strong>Salary:</strong> " . $row['salary'] . "</p>";
                    echo "</div>";
                }
            } else {
                echo "0 results";
            }
            $conn->close();
            ?>
        </div>
    </div>

    <!-- Modal for Add Seller -->
    <div id="addModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
            <span class="close">&times;</span>
            <form id="addForm" enctype="multipart/form-data">
                <label for="seller_id">Seller ID:</label><br>
                <input type="text" id="seller_id" name="seller_id" required><br>
                <label for="username">Username:</label><br>
                <input type="text" id="username" name="username" required><br>
                <label for="password">Password:</label><br>
                <input type="password" id="password" name="password" required><br>
                <label for="email">Email:</label><br>
                <input type="text" id="email" name="email" required><br>
                <label for="fullName">Full Name:</label><br>
                <input type="text" id="fullName" name="fullName" required><br>
                <label for="phoneNumber">Phone Number:</label><br>
                <input type="text" id="phoneNumber" name="phoneNumber" required><br>
                <label for="address">Address:</label><br>
                <input type="text" id="address" name="address" required><br>
                <label for="salary">Salary:</label><br>
                <input type="text" id="salary" name="salary" required><br>
                <label for="photo">Photo:</label><br>
                <input type="file" id="photo" name="photo" required><br>
                <button type="button" id="submitBtn">Submit</button>
            </form>
        </div>
    </div>

    <!-- Modal for Delete Seller -->
    <div id="deleteModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
            <span class="close">&times;</span>
            <p>Enter username of seller to delete:</p>
            <input type="text" id="deleteUsername">
            <button type="button" id="deleteConfirmBtn">Confirm</button>
        </div>
    </div>

    <script>
        // Get the modal for adding seller
        var addModal = document.getElementById("addModal");

        // Get the button that opens the modal for adding seller
        var addBtn = document.getElementById("addBtn");

        // Get the <span> element that closes the modal for adding seller
        var addSpan = document.getElementsByClassName("close")[0];

        // When the user clicks the button to add seller, open the modal
        addBtn.onclick = function() {
            addModal.style.display = "block";
        }

        // When the user clicks on <span> (x) to close the modal for adding seller
        addSpan.onclick = function() {
            addModal.style.display = "none";
        }

        // Get the modal for deleting seller
        var deleteModal = document.getElementById("deleteModal");

        // Get the button that opens the modal for deleting seller
        var deleteBtn = document.getElementById("deleteBtn");

        // Get the <span> element that closes the modal for deleting seller
        var deleteSpan = document.getElementsByClassName("close")[1];

        // When the user clicks the button to delete seller, open the modal
        deleteBtn.onclick = function() {
            deleteModal.style.display = "block";
        }

        // When the user clicks on <span> (x) to close the modal for deleting seller
        deleteSpan.onclick = function() {
            deleteModal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal for adding seller, close it
        window.onclick = function(event) {
            if (event.target == addModal) {
                addModal.style.display = "none";
            } else if (event.target == deleteModal) {
                deleteModal.style.display = "none";
            }
        }

        // JavaScript for button functionality
        document.getElementById('submitBtn').addEventListener('click', function() {
            var form = document.getElementById('addForm');
            var formData = new FormData(form);

            // Debugging alerts
            alert("Before AJAX call"); // Add this line

            // AJAX call to PHP to add the seller
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "add_seller.php", true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    alert("AJAX Response Received"); // Add this line
                    alert(xhr.responseText);
                    addModal.style.display = "none"; // Close the modal after submission
                    window.location.reload(); // Reload the page to show the updated seller list
                }
            };
            xhr.send(formData);

            alert("After AJAX call"); // Add this line
        });

        // JavaScript for delete confirmation
        document.getElementById('deleteConfirmBtn').addEventListener('click', function() {
            var username = document.getElementById('deleteUsername').value;
            if (confirm("Are you sure you want to delete the seller with username '" + username + "'?")) {
                // AJAX call to PHP to delete the seller
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_seller.php", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        alert(xhr.responseText);
                        deleteModal.style.display = "none"; // Close the modal after deletion
                        window.location.reload(); // Reload the page to show the updated seller list
                    }
                };
                xhr.send("username=" + username); // Pass the username in the request body
            }
        });
    </script>
</body>
</html>
